# Verbinden met een databank

## Flask en DB / migraties

- Flask geen ondersteuning voor DB => Python ecosysteem
- SQLAlchemy / ORM / klassen en objecten => DB instructies

```Bash
pip install flask-sqlalchemy
```

<table>
<tr>
    <th>device id</th>
    <th> lamp1 </th>
    <th> lamp2 </th>
    <th> lamp3 </th>
</tr>
{% for t in ids %}
<tr>
    <td>{{t.device_id}}</td>
    <td>lamp1</td>
    <td>lamp2</td>
    <td>lamp3</td>
</tr>
{% endfor %}
</table>

{ID:LAMP_AAN/UIT:LAMP1STATUS:LAMP2STATUS:LAMP3STATUS:LONGPS:LATGPS:BAT}


- DB schema => aanpassingen in de loop vd ontwikkeling
- Migraties => Alembic framework

```Bash
pip install flask-migrate
```

## Flask-SQLAlchemy configuratie

- SQLAlchemy ondersteunt verschillende relationele db
- Config variable SQLALCHEMY_DATABASE_URI = de plaats waar we onze db gaan zetten
- SQLALCHEMY_TRACK_MODIFICATIONS => koppelt elke wijziging in object terug naar de app en dat willen we verhinderen

## Database models

- Nieuwe models.py module aanmaken
- Klasse schrijven voor elke soort entiteit die we in db willen opslaan
- Erven van db.Model, base klasse voor alle modellen
- from app import db, in models.py
- Klasse variabelen voor alle attributen
- id pk = unieke identifier / toevoegen aan alle tabellen!
- index, unique, default=functie
- __repr__-method

```Bash
from app.models import Gebruiker
g = Gebruiker(gebruikersnaam='kristof', email='kristof.michiels01@ap.be')
g
```

## Migration repository aanmaken / eerste migratie

- flask db init
- maakt een migrations dir aan / Python scripts die wijzigingen aan DB aanbrengt / deel van source control
- flask db migrate -m "Gebruikers en posts table" => maakt een migratiescript aan
- upgrade / downgrade mogelijkheden. Moet je niet volledig kennen maar begrip is nuttig
- Nog niet toegevoegd aan de db
- flask db upgrade
- Downgrade / upgrade workflow
- flask db downgrade
- Flexibel framework
- flask db history

## Relaties

SQLAlchemy documentatie is zeer nuttig om te consulteren bij het maken van je eigen toepassingen
https://flask-sqlalchemy.palletsprojects.com/en/3.0.x/

- Hier post - gebruiker
- relatie 
- gebruiker_id = db.Column(db.Integer, db.ForeignKey("gebruiker.id"))
- posts = db.relationship("Post", backref="auteur", lazy="dynamic")


## Spelen met de DB

>>> from app import db
>>> from app.models import Gebruiker, Post
>>> u = Gebruiker(gebruikersnaam='Ben', email='ben@ap.be')
>>> db.session.add(u)
>>> db.session.commit()
>>> u = Gebruiker(gebruikersnaam='Linda', email='linda@ap.be')
>>> db.session.add(u)
>>> db.session.commit()
>>> Gebruikers = Gebruiker.query.all()
>>> Gebruikers
[<Gebruiker Ben>, <Gebruiker Linda>]
>>> for g in Gebruikers:
...     print(g.id, g.Gebruikersnaam)
...
1 Ben
2 Linda
>>> g = Gebruiker.query.get(1)
>>> g
<Gebruiker Ben>
>>> g = Gebruiker.query.get(1)
>>> p = Post(body='Eerste post!', auteur=g)
>>> db.session.add(p)
>>> db.session.commit()
>>> g = Gebruiker.query.get(1)
>>> g
<Gebruiker Ben>
>>> posts = g.posts.all()
>>> posts
[<Post Eerste post!>]


>>> g = Gebruiker.query.get(2)
>>> g
<Gebruiker Linda>
>>> g.posts.all()
[]

>>> posts = Post.query.all()
>>> for p in posts:
...     print(p.id, p.auteur.gebruikernaam, p.body)
...
1 Ben Eerste post!
>>> Gebruiker.query.order_by(Gebruiker.gebruikernaam.desc()).all()
[<Gebruiker Ben>, <Gebruiker Linda>]

>>> Gebruikers = Gebruiker.query.all()
>>> for g in Gebruikers:
...     db.session.delete(g)
...
>>> posts = Post.query.all()
>>> for p in posts:
...     db.session.delete(p)
...
>>> db.session.commit()


## Shell context

- Maakt het gemakkelijk om de Flask shell te gebruiken

``` Bash
(venv) $ flask shell
>>> db
<SQLAlchemy engine=sqlite:////Gebruikers/migu7781/Documents/dev/flask/microblog2/app.db>
>>> Gebruiker
<class 'app.models.Gebruiker'>
>>> Post
<class 'app.models.Post'>
```