
from app import app, db
import paho.mqtt.client as mqtt
import base64
import json
import certifi
import sqlite3


APPID  = "portofantwerp-2023@ttn"
PSW    = 'NNSXS.2F7ZVD6AVRIBI4O7WOYSTPKDWMPG66NL2L6CARI.K3EHQPN5FLRTSTBF6NBJ4LPKF7V4Z2QVZQ5LMTBMGGPLMUN44EIA'

conn = sqlite3.connect("LoRa.db", check_same_thread=False)

client = mqtt.Client()

#subscriben op de mqtt topic van alle devices
def on_connect(client, userdata, flags, rc):
    print("Connected with result code " + str(rc))
    topic = "#"
    #topic = "v3/{}/devices/{}/up".format(APPID,"eui-a8610a30373d9301") 
    client.subscribe(topic,0)

#ontvangen berichten van de devices verwerken
def on_message(client, userdata, msg):
    x = json.loads(msg.payload.decode('utf-8'))
    print(x); 
    device_id = x["end_device_ids"]["device_id"]

    if "uplink_message" in x:
        print(f"device id is {device_id}")
        payoload = x["uplink_message"]["decoded_payload"]["payload"]
        print(f"de payload is {payoload}")

        print(type(payoload))
        payoload_data=list(payoload.split(":"))

        payoload_data = [int(i) for i in payoload_data]

        print(payoload_data)

        print(type(payoload_data))
        print(type(payoload_data[0]))

        id = conn.execute(f"SELECT device_id from sensordata WHERE device_id='{device_id}'")
        ids = id.fetchall()

        if len(ids) == 0:
            conn.execute(f"INSERT INTO sensordata (device_id,aan_uit,lamp1,lamp2,lamp3, lichtdetectie) VALUES ('{device_id}','{payoload_data[0]}','{payoload_data[1]}','{payoload_data[2]}','{payoload_data[3]}','{payoload_data[4]}')")
            conn.commit()
            print("niet gevonden")

        else:
            conn.execute(f"UPDATE sensordata set aan_uit='{payoload_data[0]}',lamp1='{payoload_data[1]}',lamp2='{payoload_data[2]}',lamp3='{payoload_data[3]}',lichtdetectie='{payoload_data[4]}' WHERE device_id = '{device_id}'")
            conn.commit()

        #het gemidelde berkennen en nodige aansturing vanuit toepassing doen
        conn.row_factory = lambda cursor, row: row[0]
        c = conn.cursor()
        gemidelde = c.execute(f"SELECT AVG(lichtdetectie) FROM sensordata where autoset = 1")
        avg = int(gemidelde.fetchall()[0])

        if avg is not None:
            print(f"het gemidelde: {avg}")
            
            if avg < 400:
                print("lamp aan door gemidelde")
                create_downlink_all("LA1")
            
            if avg > 600:
                print("lampen uit door gemidelde")
                create_downlink_all("LA0")

#verbinding afsluiten
def on_disconnect(client, userdata, rc):
    print("Disconnected with result code " + str(rc))

#sturen naar 1 bepaalde device
def create_downlink(data,device_id):
    data = data.encode("ascii")
    data = base64.b64encode(data)
    data = data.decode("ascii")
    print(data)
    payload = {
    "downlinks": [
            {
                "f_port": 1,                    
                "frm_payload": str(data),  
               "priority": "NORMAL"          
            }
        ]
    }
    
    payload_json = json.dumps(payload)
    topic = "v3/{}/devices/{}/down/push".format(APPID, device_id)  
    client.publish(topic,payload_json)


#sturen naar alle devices die op auto staan
def create_downlink_all(data):

    data = data.encode("ascii")
    data = base64.b64encode(data)
    data = data.decode("ascii")
    print(f"data naar alle devices {data}")
    conn.row_factory = lambda cursor, row: row[0]
    c = conn.cursor()
    idlist = c.execute(f"SELECT device_id FROM sensordata where autoset = 1").fetchall()
    print(idlist)

    for id in idlist:
        autoset = c.execute(f"SELECT autoset FROM sensordata").fetchall()
        print(autoset)
    
        payload = {
            "downlinks": [
                {
                    "f_port": 1,                    
                    "frm_payload": str(data),  
                "priority": "NORMAL"          
                }
            ]
        }
        payload_json = json.dumps(payload)
        topic = "v3/{}/devices/{}/down/push".format(APPID, id)  
        client.publish(topic,payload_json)


#gepubliseerd bricht status bekijken
def on_publish(client, userdata, mid):
    print("Message published with MID: " + str(mid))
    

cafile = certifi.where()


#de callback functies zetten
client.on_connect = on_connect
client.on_message = on_message
client.on_publish= on_publish

#verbinding maken met mqtt broker
client.enable_logger()
client.tls_set(ca_certs=certifi.where())
client.username_pw_set(APPID, PSW)
client.connect("eu1.cloud.thethings.network", 8883,60)

client.loop_start() 
