# logica van de toepassing
""" from app.forms import InlogForm
 """""" from app.models import Gebruiker """
from flask import render_template, flash, redirect, url_for, request, Flask
from flask_login import login_user, logout_user, current_user, login_required
from werkzeug.urls import url_parse
from app import app, db
from app.models import sensordata, Gebruiker
from app.forms import InlogForm, RegistratieForm
from app.ttn2 import create_downlink, create_downlink_all
#import app.ttn


@app.route("/",methods=["GET","POST"])
def index():
    if request.method == "POST":
        optie = request.form['devices']
        device = sensordata.query.filter_by(device_id=optie).first()
        ids = db.session.execute(db.select(sensordata).order_by(sensordata.device_id)).scalars()
        print(device.device_id)
        return render_template("base.html", device=device,ids=ids)

    ids = db.session.execute(db.select(sensordata).order_by(sensordata.device_id)).scalars()
    return render_template("base.html",ids=ids)


@app.route("/light/<device_id>", methods=["POST"])
def light(device_id):
    device = sensordata.query.filter_by(device_id=device_id).first()
    ids = db.session.execute(db.select(sensordata).order_by(sensordata.device_id)).scalars()
    value = request.form.get("submit")
    print(value)
    if value == "aan" or value == "uit":
            device.autoset = 0
            db.session.commit()
            if value == "aan":
                print("lamp aan")
                create_downlink("LA1",device_id)
            if value == "uit":
                print("lamp uit")
                create_downlink("LA0",device_id)


    if value == "auto":
        print("set auto")
        device.autoset = 1
        db.session.commit()
    return render_template("base.html",ids=ids, device=device)


@app.route("/lights",methods={"POST"})
def alllights():
    devices = db.session.execute(db.select(sensordata).order_by(sensordata.device_id)).scalars()
    value = request.form.get("submit")
    
    if value == "aan" or value == "uit":
        for device in devices:
            device.autoset = 0
        db.session.commit()

        if value == "aan":
            print("lampen aan")
            create_downlink_all("LA1")
        if value == "uit":
            print("lampen uit")
            create_downlink_all("LA0")
            
    if value == "auto":
        for device in devices:
            device.autoset = 1
        db.session.commit()
        print("lampen auto")


    return redirect(url_for("index"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
         return redirect(url_for("index"))
    form = InlogForm() 
    if form.validate_on_submit():
        gebruiker = Gebruiker.query.filter_by(gebruikersnaam=form.gebruikersnaam.data).first()

        if gebruiker is None or not gebruiker.controleer_wachtwoord(form.wachtwoord.data):
            return redirect(url_for("login"))
    
        login_user(gebruiker)
        return redirect(url_for("index"))
    return render_template("login.html",form=form)


@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for("index"))


@app.route("/regristreer", methods=["GET", "POST"])
def regristreer():
    form = RegistratieForm()
    if form.validate_on_submit():
         gebruiker = Gebruiker(gebruikersnaam=form.gebruikersnaam.data, email=form.email.data)
         gebruiker.maak_wachtwoord(form.wachtwoord.data)
         db.session.add(gebruiker)
         db.session.commit()
         return redirect(url_for("login"))
    return render_template("registreer.html",form=form)
