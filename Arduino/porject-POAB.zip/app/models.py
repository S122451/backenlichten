from datetime import datetime
from app import db, login
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class Gebruiker(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    gebruikersnaam = db.Column(db.String(64), index=True, unique=True)
    email = db.Column(db.String(120), index=True, unique=True)
    wachtwoord_hash = db.Column(db.String(128))

    def __repr__(self):
        return "<Gebruiker {}>".format(self.gebruikersnaam)

    def maak_wachtwoord(self, wachtwoord):
        self.wachtwoord_hash = generate_password_hash(wachtwoord)

    def controleer_wachtwoord(self, wachtwoord):
        return check_password_hash(self.wachtwoord_hash, wachtwoord)

@login.user_loader
def load_user(id):
    return Gebruiker.query.get(int(id))

class sensordata(db.Model):
    device_id = db.Column(db.String(64),primary_key=True)
    aan_uit = db.Column(db.Integer)
    lamp1 = db.Column(db.Integer)
    lamp2 = db.Column(db.Integer)
    lamp3 = db.Column(db.Integer)
    lichtdetectie = db.Column(db.Integer)
    autoset = db.Column(db.Integer)
    #batterij = db.Column(db.Integer)

"""     def __repr__(self):
        return self.device_id """


""" class Gebruiker(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    gebruikersnaam = db.Column(db.String(64), index=True, unique=True)
    email = db.Column(db.String(120), index=True, unique=True)
    wachtwoord_hash = db.Column(db.String(128))
    posts = db.relationship("Post", backref="auteur", lazy="dynamic")

    def __repr__(self):
        return "<Gebruiker {}>".format(self.gebruikersnaam)


class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    body = db.Column(db.String(140))
    timestamp = db.Column(db.DateTime, index=True, default=datetime.utcnow)
    gebruiker_id = db.Column(db.Integer, db.ForeignKey("gebruiker.id"))

    def __repr__(self):
        return "<Post {}>".format(self.body) """
