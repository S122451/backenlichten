from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import ValidationError, DataRequired, Email, EqualTo
from app.models import Gebruiker


class InlogForm(FlaskForm):
    gebruikersnaam = StringField("Gebruikersnaam", validators=[DataRequired()])
    wachtwoord = PasswordField("Wachtwoord", validators=[DataRequired()])
    herinner_me = BooleanField("Herinner me")
    submit = SubmitField("Inloggen")

class RegistratieForm(FlaskForm):
    gebruikersnaam = StringField("Gebruikersnaam", validators=[DataRequired()])
    email = StringField("Email", validators=[DataRequired(), Email()])
    wachtwoord = PasswordField("Wachtwoord", validators=[DataRequired()])
    wachtwoord2 = PasswordField(
        "Herhaal wachtwoord", validators=[DataRequired(), EqualTo("wachtwoord")]
    )
    submit = SubmitField("Registreer")

    def validate_gebruikersnaam(self, gebruikersnaam):
        gebruiker = Gebruiker.query.filter_by(
            gebruikersnaam=gebruikersnaam.data
        ).first()
        if gebruiker is not None:
            raise ValidationError("Kies een andere gebruikersnaam.")

    def evalidate_mail(self, email):
        gebruiker = Gebruiker.query.filter_by(email=email.data).first()
        if gebruiker is not None:
            raise ValidationError("Kies een ander email-adres.")